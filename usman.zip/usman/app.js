// STRING METHODS
// Assignment # 21-25 JAVASCRIPT

// Q1
// var fName,lName,fullName;
// fName=prompt("Enter Your First Name:");
// lName=prompt("Enter Your Last Name:");
// fullName = fName+" "+lName;
// document.write("Greetings"+" "+fullName);

// Q2
// var fPhone,len;
// fPhone=prompt("Enter Your Favourite Phone:");
// len = fPhone.length;
// window.alert("Your Favourite Phone is:"+" "+fPhone+"\n"+"Length of String:"+" "+len);

// Q3
// var word;
// word="Pakistani";
// var i = word.indexOf("n");
// document.write("String:"+" "+word+"<br>"+"Index of 'n':"+" "+i);

// Q4
// var str,len;
// str="Hello World";
// len=str.lastIndexOf('l');
// document.write("String"+" "+str+"<br>"+"Index of 'l':"+" "+len);

// Q5
// var str="Pakistani",cha;
// cha=str[3];
// window.alert("String:"+" "+str+"\n"+"Character at index 3:"+" "+cha);

// Q6
// var fullName,fName,lName;
// fName=prompt("Enter Your First Name:");
// lName=prompt("Enter Your Last Name:");
// fullName = fName.concat(" "+lName);
// alert("Greetings"+" "+fullName);

// Q7
// var i="Hyderabad";
// var n=i.replace("Hyder","Islam");
// alert("City:"+" "+i+"\n"+"After Replacement:"+" "+n);

// Q8
// var message = "Ali and Sami are best friends.They play cricket and football together.";
// var newM = message.replace(/and/g,'&');
// document.write(newM);


// Q9
// var val1="472",val2;
// val2=Number(val1);
// document.write("Value:"+" "+val1+"<br>"+"Type:"+" "+typeof(val1)+"<br>"+"Value:"+" "+val2+"<br>"+"Type:"+" "+typeof(val2));

// Q10
// var inp,uP;
// inp=prompt("Enter Word:");
// uP=inp.toLocaleUpperCase();
// document.write("User input:"+" "+inp+"<br>"+"Upper case:"+" "+uP);

// Q11
// var inp,i,remain;
// inp=prompt("Enter a word:");
// i = inp.slice(0,1);
// remain= inp.slice(1);
// i = i.toLocaleUpperCase();
// var re= i+remain;
// document.write("User input:"+" "+inp+"<br>"+"Title case:"+" "+re);

// Q12
// var num,cNum;
// num=35.36;
// cNum=num.toString();
// cNum = cNum.replace('.',"");
// document.write("Number:"+" "+num+"<br>"+"Result:"+" "+cNum);

// Q13
// var userName,i;
// userName=prompt("Enter UserName:");
// for ( i = 0;i <= userName.length ;i++) {
//     if(userName[i]==='[@.33')
//     {
//         alert(userName+"\n"+"Please Enter a valid Username.");
//     }

// }
// alert("Valid UserName.");


// Q14
// var inP;
// var arr = ['cake','apple pie','cookie','chips','patties'];
// inP=prompt("Welcome to ABC Bakery.What do You want to order sir/ma\'am?");
// inP = inP.toLowerCase();
// for(var i=0;i<arr.length;i++){
//     if(inP===arr[i])
//     {
//         alert(inP+" "+"is found at index"+" "+i+" "+"in our bakery.");
//         break;
//     }
// else if(inP!==arr[i]){
//     alert("Sorry"+" "+inP+" "+"is not availble in our bakery");
//     break;
// }
        
    
// }


// Q15*


// Q16
// var university = "University of Karachi";
// var arr;


//  arr =  university.split("");



// for (var j = 0; j < arr.length; j++) {
//     document.write(arr[j]+"<br>");
    
// }

// Q17*
// var inpt,re;
// inpt=prompt("Enter a word of your choice:");
// for (var i = 0; i <= inpt.length; i++)
//  {
//     if(i===Number(inpt.length))
//     {
// re=inpt[i];
//     }
// }

// alert("User Input:"+" "+inpt+'\n'+'Last character of input:'+' '+re);

// Q18
var text="The quick brown fox jumps over a lazy dog.";
var txt = 'THE';
var chk;
for (var i = 0; i <text.length; i++) 
{
  chk =  text.slice(i,3);
  chk = chk.toUpperCase();
  if(txt===chk)
  {
      j++;
  }
}
document.write("Text:"+" "+text+'<br>'+"There are"+" "+j+" " +"occurrence(s) of word 'the'");
