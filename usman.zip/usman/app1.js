// Alerts
// Q1
// window.alert("Assalam O Alaikum Hazrat","Khush Aamdeed");


// Q2
// window.alert("Error! Please enter a valid number");
// Q3
// window.alert("Welcome to JS land \n Happy Coding");
//Q4
// window.alert("Welcome to JS Land");
// window.alert("Happy Coding \n Prevent this page from creating addtional dialogs. ")
//Q5
// window.alert("Hello...I can run JS through my web browser's console")
//Q6
// function myFunction() {
//     alert("Aur bhai koe kaam tha?");
//   }





// Variables For Strings

// Q1
// var username;

// Q2
// var myName;
// myName="Muhammad Ibrahim Alvi";

// Q3
// var message;
// message ="Hello World";
// alert(message);

// Q4
// var name,age,job;
// name = prompt("Enter Your Name");
// age = parseInt(prompt("Enter Your Age"));
// job = prompt("Enter Your Job:")

// alert("Your Name is"+" "+name);

// alert("Your age is"+" "+age);

// alert("Your job is"+" "+job);

// Q5

// var a=("pizza \n pizz \n piz \n pi \n p")
// alert(a)



// Q6
// var email;
// email ="Ebrahimalvi2@gmail.com";
// alert("Your email is:"+" "+ email);



// Q7
// var book = "A smart way to learn Javascript" ;
// alert("I\'m trying to learn from the Book"+" "+book);


// Q8
// document.write("Yah! I can write HTML content through JavaScript");

//  Q9
// var a ="▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬";
// alert(a);




// Variables For Numbers
// Q1
// var age = 20;
// alert("Your Age is"+" "+age);


// Q2


// Q3
// var birthYear;
// birthYear = 1999;
// document.write("My birthyear is "+" "+birthYear+ "<br/>");
// document.write("DataType of my declared variable is"+" "+ typeof(birthYear));


// Q4
// var nam,quant,prod;
// nam =prompt("Enter Your Name");
// quant =parseInt(prompt("Enter the Quantity of your product "));
// prod=prompt("Enter Product Name");
// document.write(nam+" "+"ordered"+" "+quant+" "+prod+" "+"on XYZ clothing store");


// Q1
// var Nam,Class,Rollno;

// Q2
// Legal
// var _nam,Cs$69,$roll,hello,num69;
// Illegal
// var 69op,c sjau,.pop,if,#hida;


// Q3
// var head="Rules for naming JS variables";
// document.write(head.fontsize(6)+"<br>"+"<br>");

// document.write("Variable names can only contain,numbers,$ and _.For example: $my_1stVariable" +"<br>");
// document.write("Variables must begin with a letter,$ or _. For example $name, _name or name"+"<br>");
// document.write("Variable names are case sensitive"+"<br>");
// document.write("Variable names should not be JS keywords");


// MATH EXPRESSIONS
// Q1
// var num1,num2,result;
// num1=parseInt(prompt("Enter First Number"));
// num2=parseInt(prompt("Enter Second Number"));
// result=num1+num2;
// document.write("Sum of"+ " "+num1+" "+"and"+" "+num2 +" "+"is"+" "+result);


// Q2
// subtraction
// var num1,num2,result;
// num1=parseInt(prompt("Enter First Number"));
// num2=parseInt(prompt("Enter Second Number"));
// result=num1-num2;
// document.write("Difference of"+ " "+num1+" "+"and"+" "+num2 +" "+"is"+" "+result);


// Multiplication
// var num1,num2,result;
// num1=parseInt(prompt("Enter First Number"));
// num2=parseInt(prompt("Enter Second Number"));
// result=num1*num2;
// document.write("Multiplication of"+ " "+num1+" "+"and"+" "+num2 +" "+"is"+" "+result);


// Division
// var num1,num2,result;
// num1=parseInt(prompt("Enter First Number"));
// num2=parseInt(prompt("Enter Second Number"));
// result=num1/num2;
// document.write("Division of"+ " "+num1+" "+"and"+" "+num2 +" "+"is"+" "+result);


// Modulus
// var num1,num2,result;
// num1=parseInt(prompt("Enter First Number"));
// num2=parseInt(prompt("Enter Second Number"));
// result=num1%num2;
// document.write("Modulus of"+ " "+num1+" "+"and"+" "+num2 +" "+"is"+" "+result);


// Q3
// var val,rem;
// document.write("Value after variable declaration is" +" "+val+"<br>");
// val = 5;
// document.write("Initial value:"+" "+val+"<br>");
// val+=1;
// document.write("Value after increment is:"+" "+val+"<br>");
// val+=13;
// document.write("Value after addition is:"+" "+val+"<br>");
// val-=1;
// document.write("Value after decrement is:"+" "+val+"<br>");
// rem=val/3;
// document.write("The Remainder is:"+" "+rem);

// Q4
// var cost =600;
// var tot;
// tot = cost *5;
// document.write("Total cost to buy a 5 tickets to a movie is"+" "+ tot+"PKR");


// Q5
// var no;
// no = parseInt(prompt("Enter The number of which you want to print a table"));
// for(var i=1;i<=10;i++)
// {
//     document.write(no+"x"+i+"="+no*i+"<br>");
// }


// Q6
// var cel,fer,re1,re2;
// cel = parseInt(prompt("Enter Celcius Temperature"));
// fer= parseInt(prompt("Enter Fahrenheit Temperature"));
// re1=(fer-32)*5/9;
// re2=(cel*9/5)+32;
// document.write(cel+"oC is"+" "+re2+"oF"+"<br>");
// document.write(fer+"oF is"+" "+re1+"oC"+"<br>");


// Q7
// var head="Shopping Cart";
// document.write(head.fontsize(6)+"<br>");
// var price1=650,price2=100,quant1,quant2,tot;

// quant1=parseInt(prompt("Enter The Quantity of First Product"));
// quant2=parseInt(prompt("Enter The Quantity of Second Product"));
// tot = (price1*quant1)+(price2*quant2);
// document.write("Price of item 1 is "+" "+price1+"<br>");
// document.write("Quantity of item 1 is "+" "+quant1+"<br>");
// document.write("Price of item 2 is "+" "+price2+"<br>");
// document.write("Quantity of item 2 is "+" "+quant2+"<br>");
// document.write("Total cost of your order is"+" "+tot);

// Q8
// var head,tot,obtTot,per;
// head="Marks Sheet"
// document.write(head.fontsize(6)+"<br>");
// tot =980;
// obtTot=parseInt(prompt("Enter Your obtained Marks"));
// per=(obtTot/tot)*100
// document.write("Total Marks:"+" "+tot+"<br>");
// document.write("Obtained Marks:"+" "+obtTot+"<br>");
// document.write("Percentage:"+" "+per+"%");


// Q9
// var head="Currency to PKR",us=10,saud=25,totPak;
// document.write(head.fontsize(6)+"<br>");
// totPak=(us*104.80)+(saud*28);
// document.write("Total currency in PKR:"+""+totPak);


// Q10
// var no=2,rel;
// rel=(no+5)*10/2;
// document.write("The Result is:"+" "+rel);


// Q11
// var curYear,birYear,age,head="Age Calculator";
// curYear=2020;
// birYear=parseInt(prompt("Enter Year Of your Birth"));
// age=curYear-birYear;
// document.write(head.fontsize(6)+"<br>");
// document.write("Current Year:"+" "+curYear+"<br>");
// document.write("BirthYear is:"+" "+birYear+"<br>")
// document.write("Your age is:"+""+age);

// Q12
// var radius,circum,area;
// radius=parseInt(prompt("Enter Radius:"));
// circum=2*(3.142)*radius;
// area=(3.142)*Math.pow(radius,2);
// document.write("Radius of the circle is:"+" "+radius+"<br>");
// document.write("The Circumference is:"+" "+circum+"<br>");
// document.write("The Area is:"+" "+area+"<br>");


// Q13
// var head="The Lifetime Supply Calculator",snack="Lays",cAge=20,mAge=61,eAmount=5;
// var tsnack =(mAge-cAge)*5;
// document.write(head.fontsize(6)+"<br>");
// document.write("Favourite Snack:"+""+snack+"<br>");
// document.write("Current Age:"+" "+cAge+"<br>");
// document.write("Estimated Maximum Age:"+" "+mAge+"<br>")
// document.write("You will need"+" "+tsnack+" " +snack+" "+"to last you until the ripe old age of"+" "+mAge);

// ANSWER 1

// var a = 10;
// document.write("RESULT" + "<br/>")

// document.write("the value of a is:" + a + "<br/>" ) 
// document.write("................................"+"<br/>")

// document.write("the value of ++a is:" + ++a + "<br/>")
// document.write("now the value is:"+ a  + "<br/>")
// document.write("the value of ++a is:" + a++ + "<br/>")
// document.write("now the value is:"+ a  + "<br/>")
// document.write("the value of ++a is:" + --a + "<br/>")
// document.write("now the value is:"+ a  + "<br/>")
// document.write("the value of ++a is:" + a-- + "<br/>")
// document.write("now the value is:"+ a  + "<br/>")

// ANSWERS 2

// var a =2; 
// var b= 1;
// var RESULT=--a - --b + ++b + b--;
// document.write("EXDPLANATION" + "<br/>")
// document.write(--a + "<br/>")
// document.write(--a - --b + "<br/>")
// document.write(--a - --b  + ++b + "<br/>")
// document.write(--a - --b  + ++b +  b-- +"<br/>")
// document.write("A is"+a + "<br/>");
// document.write("B is" +b + "<br/>");
// document.write("result is"+RESULT + "<br/>");

// ANSWERS 3

// var a = prompt("enter your name");
// alert("welcome"+" " +a)


// ANSWER 4

// var a = prompt("enter any num")
// for( i=1 ; i<=10; i++)
// {

//     document.write(a*i +"<br/>");
    
// }

// if(a  = " ")
// {
//     for(i=0 ; i<=10 ; i++)
//     {
//         document.write(5*i + "<br/>")
//     }
// } 





// ANSWERS 5

// var a = prompt("enter sub one")
// var b = prompt("enter sub two")
// var c = prompt("enter sub three")
// var d= prompt("enter first obtain marks")
// var e= prompt("enter second obtain marks")
// var f= prompt("enter third obtain marks")
// var g = a;
// var h = b;
// var i = c;
// var j = d;
// var k = e;
// var l = f;
//  var result =  j +k +l/300 *100
//  alert(result) 


// Chapter Assignment #9-10 JAVASCRIPT USER INPUT & CONDITIONAL STATEMENT


// Q1
// var city;
// city = prompt("Enter City");
// if(city==="Karachi"||city==="karachi")
// {
//     document.write("Welcome To City of Lights.");
// }
// else{
//     document.write("Get Lost.");
// }



// Q2
// var gender;
// gender = prompt("Enter Gender:");
// if(gender==="male"||gender==="Male")
// {
//     document.write("Good Morning Sir.");
// }
// else{
//     document.write("Good Morning Ma\'am.");
// }


// Q3
// var color;
// color=prompt("Enter Color Traffic Signal:");
// if(color==="red"||color==="Red")
// {
//     document.write("Must Stop");
// }
// else if(color==="yellow"||color==="Yellow")
// {
//     document.write("Ready to Move");
// }
// else{
    

//     document.write("Move Now");

// }



// Q4
// var rFuel;
// rFuel = parseInt(prompt("Enter The Remaining Fuel of the Car:"));
// if(rFuel<0.25){
//     alert("Please refill the fuel in your car");
// }
// else{
//     alert("Keep Driving");
// }


// Q5
// var a = 4;
// if (++a === 5){
// alert("given condition for variable a is true");}

// var b = 82;
// if (b++ === 83){
// alert("given condition for variable b is true");}

// var b = 82;
// if (b++ === 83){
// alert("given condition for variable b is true");
// }

//  var c = 12;
// if (c++ === 13){
// alert("condition 1 is true");
// }
// if
// (c === 13){
// alert("condition 2 is true");
// }
// if (++c < 14){
// alert("condition 3 is true");
// }
// if(c === 14){
// alert("condition 4 is true");
// }



// var materialCost = 20000;
// var laborCost = 2000;
// var totalCost = materialCost + laborCost;
// if (totalCost === laborCost + materialCost){
// alert("The cost equals");
// }


// var inp;
// inp = prompt("Enter True or False");
// if (true){
// alert("True");
// }
// if (false){
// alert("False");
// }

// var car,cat;
// car=parseInt(prompt("Enter Value of car"));
// cat=parseInt(prompt("Enter Value of cat"));
// if("car" < "cat"){
//     alert("car is smaller than cat");
//     }


// Q6
// var tot ,oTot,percent,head="Marks Sheet";
// tot=parseInt(prompt("Enter Total Marks"));
// oTot=parseInt(prompt("Enter Obtained Marks"));
// percent = (oTot/tot)*100;
// document.write("Total Marks:"+" "+tot+"<br>");
// document.write("Obtained Marks:"+" "+oTot+"<br>");
// document.write("Percentage:"+" "+percent+"<br>");
// if(percent>=80){
//     document.write("Grade: A-One"+"<br>");
//     document.write("Remarks:"+" "+"Excellent");
// }
// else if(percent>=70){
//     document.write("Grade: A"+"<br>");
//     document.write("Remarks:"+" "+"Good");
// }
// else if(percent>=60){
//     document.write("Grade: B"+"<br>");
//     document.write("Remarks:"+" "+"You need to improve");
// }
// else{
//     document.write("Grade: Fail"+"<br>");
//     document.write("Remarks:"+" "+"Sorry");
// }


// Q7
// var no=5;
// var inp;
// inp = parseInt(prompt("Enter a number from 1-10:"));
// if(inp===no){
//     alert("Bingo! Correct Answer.");
// }

// if(inp+=no){
//     alert("Close enough to correct answer.");
// }


// Q8
// var no;
// no= parseInt(prompt("Enter Number:"));
// if(no%3===0){
//     alert("The number"+" "+no +" "+"Is divisble by 3");
// }
// else{
//     alert("The given nnumber is not divisble by 3.");
// }


// Q9
// var no;
// no =parseInt(prompt("Enter The desired Number:"));
// if(no%2===0)
// {
    // alert("The Input number is even");   
// }
// else{
//     alert("Not an even number");
// }


// Q10
// var temp;
// temp=parseInt(prompt("Enter Temperature:"));
// if(temp>40){
//  alert("The Weather today is Hot.");
// }

// else if(temp>30){
//     alert("The Weather is Normal.");
// }
// else if(temp>20){
//     alert("Today\'s Weather is Cool.");
// }
// else{
   
//         alert("OMG! Today\'s Weather is so Cool.");
      
// }


// Q11
// var inpt1,inpt2,result;
// inpt1 = parseInt(prompt("Enter First Number"));
// inpt2 = parseInt(prompt("Enter Second Number"));
// var op;
// op = prompt("Enter Operator:");
// if(op==="+"){
//     result = inpt1+inpt2;
//     alert("The Addition of two numbers is:"+" " +result);
// }
// else if(op==="-"){
//     result = inpt1-inpt2;
//     alert("The Subtraction of two numbers is:"+" " +result);
// }
// else if(op==="*"){
//     result = inpt1*inpt2;
//     alert("The Multiplication of two numbers is:"+" " +result);
// }
// else if(op==="/"){
//     result = inpt1/inpt2;
//     alert("The Division of two numbers is:"+" " +result);
// }
// else{
//     result = inpt1%inpt2;
//     alert("The Mod is:"+" "+result);
// }



// Assignment #12-13 JAVASCRIPT IF...ELSE & ELSE IF STATEMENT, TESTING SET OF CONDITIONS
// Q1
